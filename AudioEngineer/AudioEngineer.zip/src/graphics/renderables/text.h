#pragma once

namespace audioengineer {
	namespace graphics {

		class Text
		{

		};
	}
}